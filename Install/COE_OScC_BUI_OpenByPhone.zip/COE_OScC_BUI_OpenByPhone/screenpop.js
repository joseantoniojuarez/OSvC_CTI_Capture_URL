//Based on original code from Dileep Mudadla
//https://community.oracle.com/customerconnect/discussion/564954/screenpop-in-agent-browser-ui-bui
//Modified by PM CoE CrossCX innovations to avoid duplicated browser tabs
//Require Chrome Extension "COE_OSvC_CaptureTab"
//Author: jose.antonio.juarez@oracle.com


var appName = 'COE_OScC_BUI_OpenByPhone';
var appVersion = '1';
var extensionProviderCache;
var extLogger;
var reportId;
var columnIndex;
var filterIndex;
var coeCtiInput;
var currentPhone;

var findCTICom = setInterval(function() {
    coeCtiInput = parent.document.getElementById('coeCtiInput');
    if (coeCtiInput) {
        if (coeCtiInput.innerText != '') {
            console.log('COE CTI New value: ', coeCtiInput.innerText);
            newCtiCall(coeCtiInput.innerText);
            coeCtiInput.innerText = '';
        }
    }
}, 1000);

function newCtiCall(phone) {
    currentPhone = phone;
    ORACLE_SERVICE_CLOUD.extension_loader.load(appName, appVersion).then(function(extensionProvider) { //BUI SDK
        //trace
        extLogger = extensionProvider.getLogger('COE_OScC_BUI_OpenByPhone');
        extensionProviderCache = extensionProvider;
        extensionProvider.getGlobalContext().then(function(globalContext) {
            globalContext.getExtensionContext(appName).then(function(extensionContext) {
                extensionContext.getProperties(['reportId']).then(function(collection) {
                    reportId = collection.get('reportId').getValue();
                    extensionProvider.registerAnalyticsExtension(function(IAnalyticsContext) {
                        IAnalyticsContext.createReport(reportId).then(function(IExtensionReport) {
                                var reportDefinition = IExtensionReport.getReportDefinition();
                                var columnDefinitions = reportDefinition.getColumnDefinitions();
                                for (var i = 0; i < columnDefinitions.length; i++) {
                                    if (columnDefinitions[i].getColumnReference() == 'contacts.c_id') { //Get the columnIndex in order to use in getCells()
                                        columnIndex = i;
                                        break;
                                    }
                                }
                                var filterDetails = IExtensionReport.getReportFilters();
                                var filterList = filterDetails.getFilterList();
                                for (var j = 0; j < filterList.length; j++) {

                                    if (filterList[j].getColumnReference() == 'contacts.any_phone;2') { //Look for filter Labelled Phone and get it's index
                                        filterIndex = j;
                                        break;
                                    }
                                }
                                filterList[filterIndex].setValue('%' + phone + '%');
                                IExtensionReport.setDataHandler(reportDataHandler);
                                IExtensionReport.executeReport();
                            },
                            function(error) {
                                extLogger.error('Error: ' + error);
                            });
                    });
                });
            });
        });
    });
}

function reportDataHandler(reportObject) {
    var reportData = reportObject.getReportData();
    var count = reportData.totalRecordCount;
    extLogger.trace('Count of rows returned is ' + count);

    if (count == 1) {
        var rowData = reportData.getRows()[0];
        var contactId = rowData.getCells()[columnIndex].getData(); //Make sure the first column of report is Contact ID as we are retrieving the data first cell
        extLogger.trace('Contact ID is ' + contactId);
        extensionProviderCache.registerWorkspaceExtension(function(WorkspaceRecord) {
            WorkspaceRecord.editWorkspaceRecord('Contact', contactId);
        });
    }
    if (count == 0) {
        extensionProviderCache.registerWorkspaceExtension(function(WorkspaceRecord) {
            WorkspaceRecord.createWorkspaceRecord('Contact', setPhoneNum);
        });
    }
}

function setPhoneNum(closeHandler) {
    closeHandler.updateField('Contact.PhMobile', currentPhone);
}